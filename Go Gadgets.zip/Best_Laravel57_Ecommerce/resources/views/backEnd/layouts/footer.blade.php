<div class="row-fluid">
    <div id="footer" class="span12">Copyright ©2015 Laravel5.7 (Cambodia). All rights reserved.</div>
</div>